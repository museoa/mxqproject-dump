
File downloaded from 
http://chinagadgetsreviews.com
or
http://chinagadgetsreviews.blogspot.com


New firmwares everyday, day by day!
Visit us for more!

Our websites: http://chinagadgetsreviews.com & http://xiaomi-pedia.com & http://www.blitzwolfarena.com
Our blog: http://chinagadgetsreviews.blogspot.com
Our Facebook Fan Page: https://www.facebook.com/ChinaGadgetsReviews
Our Youtube channel: https://www.youtube.com/user/chinaproductsreviews
Our Google+ pages: https://plus.google.com/u/1/+ChinaGadgetsReviews 
& https://plus.google.com/b/117117575244708597841/+Chinagadgetsreviewsofficial
Twitter: https://twitter.com/NewChinaGadget
Flickr: https://www.flickr.com/photos/cgreviews/sets
Get 'Download Android Firmwares' Android application free from Play Store 
https://play.google.com/store/apps/details?id=com.conduit.app_72c01defc1e54487adfba430f7050cfb.app
or download the .apk file from here http://android_addicted.mobapp.at 